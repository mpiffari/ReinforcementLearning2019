function reward = RewardCartPole()
    global cart
    reward = cart.dT;
end

