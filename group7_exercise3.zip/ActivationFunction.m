classdef ActivationFunction
   enumeration
      TLU, 
      Sign, %Not implemented
      Linear,
      Piece_wise_linear, % Not implemented
      Sigmoid,
      Hyperbolic % Not implemented
   end
end

