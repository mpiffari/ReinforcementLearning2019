function r = Reward(x,L)
    r = (x - L)^2;
end

